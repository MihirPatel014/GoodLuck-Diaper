/**
 * Centralized Store Configuration
 * Single source of truth for store details, contact, and WhatsApp ordering.
 */

export interface StoreConfig {
  name: string;
  tagline: string;
  eyebrow: string;
  description: string;
  /**
   * International format without +, spaces, brackets, or dashes.
   * e.g., '919876543210'
   */
  whatsappNumber: string;
  email: string;
  phoneDisplay: string;
  address: string;
  workingHours: string;
  currency: {
    symbol: string;
    code: string;
  };
  social: {
    instagram: string;
    facebook: string;
    whatsapp: string;
  };
  trustMetrics: {
    parentsCount: string;
    rating: string;
    satisfaction: string;
  };
}

export const storeConfig: StoreConfig = {
  name: "BabyHub",
  tagline: "Because Your Baby Deserves The Best",
  eyebrow: "WE GIVE OUR BEST",
  description: "Explore our range of organic, safe, and thoughtfully designed baby care products. Trusted by parents worldwide.",
  // Central WhatsApp configuration (pure digits, international format)
  whatsappNumber: "919876543210",
  email: "care@babyhubstore.com",
  phoneDisplay: "+91 98765 43210",
  address: "Greenwood Boulevard, Eco Park, Suite 402",
  workingHours: "Mon - Sat: 9:00 AM - 7:00 PM (IST)",
  currency: {
    symbol: "$",
    code: "USD",
  },
  social: {
    instagram: "https://instagram.com/babyhubcare",
    facebook: "https://facebook.com/babyhubcare",
    whatsapp: "https://wa.me/919876543210",
  },
  trustMetrics: {
    parentsCount: "10k+",
    rating: "4.9/5",
    satisfaction: "99.4%",
  },
};
