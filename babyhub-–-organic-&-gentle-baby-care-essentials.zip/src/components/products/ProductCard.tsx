import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Product } from '../../lib/products';
import { ProductPrice } from './ProductPrice';
import { WhatsAppProductButton } from '../whatsapp/WhatsAppProductButton';
import { Sparkles, Eye, ArrowUpRight } from 'lucide-react';

export interface ProductCardProps {
  product: Product;
  className?: string;
  showCategory?: boolean;
}

export function ProductCard({
  product,
  className = '',
  showCategory = true,
}: ProductCardProps) {
  const [imgError, setImgError] = useState(false);

  return (
    <div
      className={`group relative flex flex-col bg-white border border-slate-100/80 rounded-2xl p-3.5 sm:p-4 transition-all duration-300 hover:shadow-lg hover:shadow-emerald-900/5 hover:-translate-y-1 ${className}`}
    >
      {/* Product Image Container */}
      <Link
        to={`/shop/${product.slug}`}
        className="relative block w-full aspect-square bg-[#F4F9F6] rounded-xl overflow-hidden mb-3.5 group-hover:bg-[#EBFBF3] transition-colors"
      >
        {!imgError ? (
          <img
            src={product.image}
            alt={product.name}
            loading="lazy"
            referrerPolicy="no-referrer"
            onError={() => setImgError(true)}
            className="w-full h-full object-contain p-4 transition-transform duration-500 group-hover:scale-105"
          />
        ) : (
          <div className="w-full h-full flex flex-col items-center justify-center p-4 bg-emerald-50 text-emerald-700">
            <Sparkles className="w-8 h-8 opacity-60 mb-2" />
            <span className="text-xs font-medium text-center">{product.name}</span>
          </div>
        )}

        {/* Floating Category Tag */}
        {showCategory && product.category && (
          <span className="absolute top-2.5 left-2.5 bg-white/90 backdrop-blur-xs text-[11px] font-semibold text-emerald-800 px-2.5 py-0.5 rounded-full shadow-xs">
            {product.category}
          </span>
        )}

        {/* Hover Quick View Overlay Pill */}
        <div className="absolute inset-0 bg-slate-900/10 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center pointer-events-none">
          <span className="inline-flex items-center gap-1.5 bg-white text-slate-800 text-xs font-semibold px-3 py-1.5 rounded-full shadow-md transform translate-y-2 group-hover:translate-y-0 transition-transform">
            <Eye className="w-3.5 h-3.5 text-[#00A86B]" />
            View Details
          </span>
        </div>
      </Link>

      {/* Product Information */}
      <div className="flex flex-col flex-grow">
        <Link
          to={`/shop/${product.slug}`}
          className="text-slate-900 hover:text-[#00A86B] font-bold text-sm sm:text-base leading-snug transition-colors line-clamp-1 mb-1"
        >
          {product.name}
        </Link>

        <p className="text-slate-500 text-xs leading-relaxed line-clamp-2 mb-3 min-h-[2rem]">
          {product.description}
        </p>

        {/* Pricing */}
        <div className="mt-auto mb-3">
          <ProductPrice
            price={product.price}
            originalPrice={product.originalPrice}
            size="md"
          />
        </div>

        {/* Action Controls: View Product + WhatsApp CTA */}
        <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-100">
          <Link
            to={`/shop/${product.slug}`}
            className="inline-flex items-center justify-center gap-1 text-xs font-semibold text-slate-700 bg-slate-50 hover:bg-slate-100 px-2.5 py-2 rounded-full transition-colors"
          >
            <span>Details</span>
            <ArrowUpRight className="w-3 h-3 text-slate-400" />
          </Link>

          <WhatsAppProductButton
            product={product}
            variant="primary"
            size="sm"
            label="WhatsApp"
            className="w-full text-xs font-semibold py-2"
          />
        </div>
      </div>
    </div>
  );
}
