import { Link } from 'react-router-dom';
import { storeConfig } from '../../config/store';
import { WhatsAppButton } from '../whatsapp/WhatsAppButton';
import { ArrowRight, Sparkles } from 'lucide-react';

export function HeroSection() {
  return (
    <section className="relative pt-6 pb-12 sm:pt-10 sm:pb-16 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Top Eyebrow & Main Title Header */}
        <div className="mb-6 sm:mb-8 max-w-2xl">
          <div className="inline-flex items-center gap-1.5 bg-[#D7F7E6] text-[#00875A] text-[11px] sm:text-xs font-bold uppercase tracking-wider px-3.5 py-1.5 rounded-full mb-4">
            <Sparkles className="w-3.5 h-3.5" />
            {storeConfig.eyebrow}
          </div>

          <h1 className="text-3xl sm:text-5xl lg:text-6xl font-black text-slate-900 tracking-tight leading-[1.12]">
            Because Your Baby <br />
            <span className="text-slate-900">Deserves The Best</span>
          </h1>
        </div>

        {/* Hero Visual Showcase and Description Grid (Matches screenshot layout) */}
        <div className="relative grid grid-cols-1 lg:grid-cols-12 gap-6 items-end">
          {/* Main Hero Card with Baby wrapped in blue blanket */}
          <div className="lg:col-span-8 relative">
            <div className="relative aspect-[16/10] sm:aspect-[16/9] w-full bg-[#E5F3FE] rounded-3xl overflow-hidden shadow-sm border border-sky-100/80">
              <img
                src="/src/assets/images/hero_baby_blanket_1791210623946.jpg"
                alt="Happy baby wrapped in soft blue blanket"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover object-center transition-transform duration-700 hover:scale-[1.02]"
              />

              {/* Gentle subtle gradient vignette for contrast */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/20 via-transparent to-transparent pointer-events-none" />
            </div>
          </div>

          {/* Side Floating / Supporting Content Box */}
          <div className="lg:col-span-4 flex flex-col justify-end">
            <div className="bg-white/90 backdrop-blur-md border border-slate-100 p-6 sm:p-7 rounded-3xl shadow-sm">
              <p className="text-sm sm:text-base text-slate-600 leading-relaxed font-medium mb-6">
                {storeConfig.description}
              </p>

              <div className="flex flex-col sm:flex-row lg:flex-col gap-3">
                <Link
                  to="/shop"
                  className="inline-flex items-center justify-center gap-2 bg-[#00A86B] hover:bg-[#00935D] text-white font-bold text-sm px-6 py-3.5 rounded-full shadow-sm hover:shadow-md transition-all duration-200"
                >
                  <span>Shop Now</span>
                  <ArrowRight className="w-4 h-4" />
                </Link>

                <WhatsAppButton
                  variant="outline"
                  size="md"
                  message="Hello BabyHub! I'd like to ask a few questions before ordering."
                  className="w-full font-bold text-xs"
                >
                  WhatsApp Consultation
                </WhatsAppButton>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
