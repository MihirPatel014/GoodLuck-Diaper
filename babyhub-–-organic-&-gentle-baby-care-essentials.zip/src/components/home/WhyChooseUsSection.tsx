import { storeConfig } from '../../config/store';
import { WhatsAppButton } from '../whatsapp/WhatsAppButton';
import { Badge } from '../ui/Badge';
import { ShieldCheck, HeartHandshake, Leaf, MessageCircleHeart, Award, CheckCircle } from 'lucide-react';

export function WhyChooseUsSection() {
  const benefits = [
    {
      icon: Leaf,
      title: 'Certified Organic & Pure',
      description: 'Zero parabens, sulfates, synthetic perfumes, or harsh chemicals. Only food-grade and gentle botanical formulas.',
    },
    {
      icon: ShieldCheck,
      title: 'Dermatologically Tested',
      description: 'Pediatrician-endorsed and clinically verified hypoallergenic for newborn delicate skin and eczema-prone toddlers.',
    },
    {
      icon: MessageCircleHeart,
      title: 'Easy WhatsApp Ordering',
      description: 'No complicated signups or passwords. Tap one button to chat with our helpful parenting support team.',
    },
    {
      icon: Award,
      title: 'Trusted Quality Guarantee',
      description: 'More than 10,000+ satisfied parents across the globe rely on our safety-first baby care formulations.',
    },
  ];

  return (
    <section className="py-14 sm:py-20 bg-gradient-to-b from-[#FAFCFA] to-[#F2F8F5]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-14">
          <Badge variant="green" className="mb-3">
            WHY CHOOSE US
          </Badge>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-black text-slate-900 tracking-tight leading-tight">
            Why Parents Choose {storeConfig.name}
          </h2>
          <p className="mt-3 text-sm text-slate-600 leading-relaxed">
            We put the health and safety of your little ones at the heart of everything we create.
          </p>
        </div>

        {/* 4 Pillars Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {benefits.map((item, idx) => {
            const Icon = item.icon;
            return (
              <div
                key={idx}
                className="bg-white rounded-2xl p-6 border border-slate-100 shadow-xs flex flex-col justify-between transition-all duration-300 hover:shadow-md hover:-translate-y-1"
              >
                <div>
                  <div className="w-12 h-12 rounded-2xl bg-[#E8FBF1] text-[#00A86B] flex items-center justify-center mb-5">
                    <Icon className="w-6 h-6" />
                  </div>
                  <h3 className="text-base font-bold text-slate-900 mb-2">
                    {item.title}
                  </h3>
                  <p className="text-xs sm:text-sm text-slate-500 leading-relaxed">
                    {item.description}
                  </p>
                </div>

                <div className="mt-6 pt-4 border-t border-slate-100 flex items-center gap-1.5 text-xs text-[#00A86B] font-semibold">
                  <CheckCircle className="w-4 h-4" />
                  <span>BabyHub Standard</span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Reassuring CTA Banner */}
        <div className="mt-12 bg-white rounded-3xl p-6 sm:p-8 border border-emerald-100/80 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-4 text-center sm:text-left">
            <div className="w-12 h-12 rounded-full bg-emerald-50 text-[#00A86B] flex items-center justify-center shrink-0 hidden sm:flex">
              <HeartHandshake className="w-6 h-6" />
            </div>
            <div>
              <h4 className="text-base sm:text-lg font-bold text-slate-900">
                Have a question about what's best for your newborn?
              </h4>
              <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
                Our team is ready on WhatsApp to assist with personalized recommendations.
              </p>
            </div>
          </div>

          <WhatsAppButton
            variant="primary"
            size="md"
            message="Hello! I would like some advice on choosing the best products for my baby."
            className="w-full sm:w-auto font-bold text-xs sm:text-sm"
          >
            Chat with Baby Care Expert
          </WhatsAppButton>
        </div>
      </div>
    </section>
  );
}
