import { Link } from 'react-router-dom';
import { ArrowUpRight, ShieldCheck, Check } from 'lucide-react';

export function TrustHighlights() {
  return (
    <section className="py-6 sm:py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5 sm:gap-6">
          {/* Card 1: Soft Light-Blue "Globally Recognized" */}
          <div className="bg-[#EBF5FF] border border-blue-100 rounded-3xl p-6 sm:p-7 flex flex-col justify-between transition-transform duration-300 hover:-translate-y-1">
            <div>
              <span className="text-[11px] font-bold uppercase tracking-wider text-blue-600 block mb-2">
                Globally Recognized
              </span>
              <h3 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight leading-snug">
                Our Products Are Trusted By 10k Happy Parents
              </h3>
            </div>

            <div className="mt-6 flex items-center justify-between pt-4 border-t border-blue-200/50">
              {/* Avatar Cluster */}
              <div className="flex -space-x-2.5 items-center">
                <div className="w-9 h-9 rounded-full bg-blue-300 border-2 border-white flex items-center justify-center text-xs font-bold text-blue-900 overflow-hidden shadow-xs">
                  <span>EM</span>
                </div>
                <div className="w-9 h-9 rounded-full bg-emerald-300 border-2 border-white flex items-center justify-center text-xs font-bold text-emerald-900 overflow-hidden shadow-xs">
                  <span>SJ</span>
                </div>
                <div className="w-9 h-9 rounded-full bg-amber-300 border-2 border-white flex items-center justify-center text-xs font-bold text-amber-900 overflow-hidden shadow-xs">
                  <span>RK</span>
                </div>
                <div className="w-9 h-9 rounded-full bg-rose-300 border-2 border-white flex items-center justify-center text-xs font-bold text-rose-900 overflow-hidden shadow-xs">
                  <span>AL</span>
                </div>
              </div>

              {/* Explore Button */}
              <Link
                to="/about"
                className="inline-flex items-center gap-1 bg-[#00A86B] hover:bg-[#00935D] text-white text-xs font-bold px-4 py-2 rounded-full transition-colors shadow-xs"
              >
                <span>Explore</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </Link>
            </div>
          </div>

          {/* Card 2: Soft Mint Green "Safety Certified" */}
          <div className="bg-[#E8FBF0] border border-emerald-100 rounded-3xl p-6 sm:p-7 flex flex-col justify-between transition-transform duration-300 hover:-translate-y-1">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-2xl bg-white text-[#00A86B] flex items-center justify-center shadow-xs shrink-0">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <div>
                <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-700 block mb-1">
                  Safety Certified
                </span>
                <h3 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight leading-snug">
                  Certified Organic, Non-Toxic, And Dermatologically Tested
                </h3>
              </div>
            </div>

            <div className="mt-6 flex flex-wrap gap-2 pt-4 border-t border-emerald-200/50">
              <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-800 bg-white/80 px-2.5 py-1 rounded-full">
                <Check className="w-3 h-3 text-[#00A86B]" /> Hypoallergenic
              </span>
              <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-800 bg-white/80 px-2.5 py-1 rounded-full">
                <Check className="w-3 h-3 text-[#00A86B]" /> 0% Parabens
              </span>
              <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-800 bg-white/80 px-2.5 py-1 rounded-full">
                <Check className="w-3 h-3 text-[#00A86B]" /> Tear-Free
              </span>
            </div>
          </div>

          {/* Card 3: Photo Card of Baby Playing on Colorful Mat */}
          <div className="relative aspect-[4/3] md:aspect-auto rounded-3xl overflow-hidden shadow-xs border border-slate-100 min-h-[200px]">
            <img
              src="/src/assets/images/baby_playing_rug_1791210810102.jpg"
              alt="Baby smiling and playing on colorful mat"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950/60 via-transparent to-transparent flex items-end p-5">
              <span className="text-white text-xs font-semibold drop-shadow-xs">
                Gentle on skin, safe for daily play & smiles.
              </span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
