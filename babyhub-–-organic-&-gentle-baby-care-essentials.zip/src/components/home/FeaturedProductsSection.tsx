import { Link } from 'react-router-dom';
import { getFeaturedProducts } from '../../lib/products';
import { ProductCard } from '../products/ProductCard';
import { Badge } from '../ui/Badge';
import { ArrowRight } from 'lucide-react';

export function FeaturedProductsSection() {
  const featured = getFeaturedProducts();
  const displayed = featured.slice(0, 3);

  return (
    <section className="py-12 sm:py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header row with Title and "All Products ->" button */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-10 gap-4">
          <div>
            <Badge variant="green" className="mb-3">
              FEATURED PRODUCTS
            </Badge>
            <h2 className="text-2xl sm:text-3xl lg:text-4xl font-black text-slate-900 tracking-tight leading-tight">
              Top Picks For <br />
              Your Little One
            </h2>
            <p className="mt-2 text-xs sm:text-sm text-slate-600 max-w-md">
              Explore Our Range Of Organic, Safe, And Thoughtfully Designed Baby Care Products.
            </p>
          </div>

          <div>
            <Link
              to="/shop"
              className="inline-flex items-center gap-2 bg-[#00A86B] hover:bg-[#00935D] text-white text-xs sm:text-sm font-bold px-6 py-2.5 rounded-full transition-colors shadow-xs"
            >
              <span>All Products</span>
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>

        {/* 3 Featured Products in Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {displayed.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </div>
    </section>
  );
}
